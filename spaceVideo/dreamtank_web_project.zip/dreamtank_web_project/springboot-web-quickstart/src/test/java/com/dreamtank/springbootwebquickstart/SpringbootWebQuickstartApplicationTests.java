package com.dreamtank.springbootwebquickstart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootWebQuickstartApplicationTests {

    @Test
    void contextLoads() {
    }

}
