package com.dreamtank.maven;

import org.junit.Test;

public class DemoTest {
    @Test
    public void test01(){
        System.out.println("hello test01!");
    }
    @Test
    public void test02(){
        System.out.println("hello test02!");
    }
    @Test
    public void test03(){
        System.out.println("hello test03!");
    }
    @Test
    public void test04(){
        System.out.println("hello test04!");
    }
}
